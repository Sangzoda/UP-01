package com.example.joni;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText usernameInput;
    private EditText passwordInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernameInput = findViewById(R.id.username);
        passwordInput = findViewById(R.id.password);
    }

    public void onLogin(View view) {
        String username = usernameInput.getText().toString();
        String password = passwordInput.getText().toString();

        User user = Database.authenticate(username, password);

        if (user != null) {
            Intent intent = new Intent(this, TourListActivity.class);
            startActivity(intent);
        } else {
            Toast.makeText(this, "Неправильное имя пользователя или пароль", Toast.LENGTH_SHORT).show();
        }
    }
}