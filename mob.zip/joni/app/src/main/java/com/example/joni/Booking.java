// Booking.java
package com.example.joni;

public class Booking {
    private String username;
    private Tour tour;

    public Booking(String username, Tour tour) {
        this.username = username;
        this.tour = tour;
    }

    public String getUsername() {
        return username;
    }

    public Tour getTour() {
        return tour;
    }
}
