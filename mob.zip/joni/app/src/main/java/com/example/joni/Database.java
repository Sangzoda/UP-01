// Database.java
package com.example.joni;


import java.util.ArrayList;
import java.util.List;

import java.util.ArrayList;
import java.util.List;

public class Database {
    private static List<User> users = new ArrayList<>();
    private static List<Tour> tours = new ArrayList<>();
    private static List<Booking> bookings = new ArrayList<>();
    private static User currentUser;

    static {
        // Добавляем пользователей
        users.add(new User("admin", "adminpass"));
        users.add(new User("user1", "password1"));

        // Добавляем тестовые туры
        tours.add(new Tour("Париж", 1500.00));
        tours.add(new Tour("Рим", 1200.00));
        tours.add(new Tour("Лондон", 1300.00));
        tours.add(new Tour("Берлин", 1100.00));
    }

    public static User authenticate(String username, String password) {
        for (User user : users) {
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                currentUser = user;
                return user;
            }
        }
        return null;
    }

    public static User getCurrentUser() {
        return currentUser;
    }

    public static List<Tour> getTours() {
        return tours;
    }

    public static void addBooking(Booking booking) {
        bookings.add(booking);
    }

    public static List<Booking> getBookings() {
        return bookings;
    }

    public static void logout() {
        currentUser = null;
    }
}



