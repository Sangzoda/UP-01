package com.example.joni;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class BookingActivity extends AppCompatActivity {

    private String destination;
    private double price;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking);

        Intent intent = getIntent();
        destination = intent.getStringExtra("destination");
        price = intent.getDoubleExtra("price", 0);

        TextView destinationView = findViewById(R.id.destination);
        TextView priceView = findViewById(R.id.price);

        destinationView.setText("Тур: " + destination);
        priceView.setText("Цена: " + price + " USD");
    }

    public void onConfirmBooking(View view) {
        Database.addBooking(new Booking("user1", new Tour(destination, price)));
        Toast.makeText(this, "Бронирование подтверждено!", Toast.LENGTH_SHORT).show();
        finish();
    }
}
