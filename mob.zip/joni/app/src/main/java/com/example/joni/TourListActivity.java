package com.example.joni;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;


import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class TourListActivity extends AppCompatActivity {

    private ListView tourListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tour_list);

        tourListView = findViewById(R.id.tourListView);

        List<Tour> tours = Database.getTours();
        List<String> tourDetails = new ArrayList<>();

        for (Tour tour : tours) {
            tourDetails.add(tour.getDestination() + " - " + tour.getPrice() + " USD");
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, tourDetails);
        tourListView.setAdapter(adapter);

        tourListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Tour selectedTour = tours.get(position);
                Intent intent = new Intent(TourListActivity.this, BookingActivity.class);
                intent.putExtra("destination", selectedTour.getDestination());
                intent.putExtra("price", selectedTour.getPrice());
                startActivity(intent);
            }
        });
    }
}
